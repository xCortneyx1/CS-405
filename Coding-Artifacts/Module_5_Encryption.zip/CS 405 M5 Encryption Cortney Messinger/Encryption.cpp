﻿// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <ctime>
#include <direct.h>   // _getcwd
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <Windows.h>  // GetModuleFileNameA
#endif

static std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const size_t key_length = key.length();
    assert(key_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source.length(); ++i)
    {
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }

    return output;
}

static std::string get_working_directory()
{
    char buffer[4096]{};
    if (_getcwd(buffer, sizeof(buffer)) != nullptr)
    {
        return std::string(buffer);
    }
    return {};
}

static std::string get_exe_directory()
{
#ifdef _WIN32
    char path[MAX_PATH]{};
    DWORD len = GetModuleFileNameA(nullptr, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH)
    {
        return {};
    }

    std::string full(path);
    const size_t slash = full.find_last_of("\\/");
    if (slash == std::string::npos)
    {
        return {};
    }
    return full.substr(0, slash);
#else
    return {};
#endif
}

static std::string try_read_whole_file(const std::string& path)
{
    std::ifstream input(path, std::ios::in);
    if (!input.is_open())
    {
        return {};
    }

    std::ostringstream buffer;
    buffer << input.rdbuf();
    return buffer.str();
}

static std::string read_file(const std::string& filename)
{
    std::cout << "Working directory: " << get_working_directory() << std::endl;

    // Build a list of common places VS might be running from
    std::vector<std::string> candidates;

    // Working directory variations
    candidates.push_back(filename);
    candidates.push_back(".\\" + filename);
    candidates.push_back("..\\" + filename);
    candidates.push_back("..\\..\\" + filename);
    candidates.push_back("..\\..\\..\\" + filename);
    candidates.push_back("..\\..\\..\\..\\" + filename);

    // EXE directory is a strong fallback (especially for instructor runs)
    const std::string exe_dir = get_exe_directory();
    if (!exe_dir.empty())
    {
        candidates.push_back(exe_dir + "\\" + filename);
    }

    for (const auto& path : candidates)
    {
        std::string data = try_read_whole_file(path);
        if (!data.empty())
        {
            std::cout << "Loaded input from: " << path << std::endl;
            return data;
        }
    }

    std::cerr << "ERROR: Unable to open input file: " << filename << std::endl;
    std::cerr << "Checked working directory, parent folders, and EXE folder." << std::endl;
    return {};
}

static std::string get_student_name(const std::string& data)
{
    const size_t newline_pos = data.find('\n');
    if (newline_pos != std::string::npos)
    {
        return data.substr(0, newline_pos);
    }
    return {};
}

static void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    std::ofstream output(filename, std::ios::out | std::ios::trunc);

    if (!output.is_open())
    {
        std::cerr << "ERROR: Unable to write file: " << filename << std::endl;
        return;
    }

    const std::time_t now = std::time(nullptr);
    std::tm local_time{};

#if defined(_WIN32)
    localtime_s(&local_time, &now);
#else
    local_time = *std::localtime(&now);
#endif

    output << student_name << "\n";
    output << std::put_time(&local_time, "%Y-%m-%d") << "\n";
    output << key << "\n";
    output << data;
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    const std::string input_file = "inputdatafile.txt";
    const std::string encrypted_file = "encrypteddatafile.txt";
    const std::string decrypted_file = "decrytpteddatafile.txt";
    const std::string key = "password";

    const std::string source_data = read_file(input_file);
    if (source_data.empty())
    {
        std::cerr << "Input data could not be loaded. Program exiting." << std::endl;
        return 1;
    }

    const std::string student_name = get_student_name(source_data);

    const std::string encrypted_data = encrypt_decrypt(source_data, key);
    save_data_file(encrypted_file, student_name, key, encrypted_data);

    const std::string decrypted_data = encrypt_decrypt(encrypted_data, key);
    save_data_file(decrypted_file, student_name, key, decrypted_data);

    std::cout << "Read File: " << input_file
        << " - Encrypted To: " << encrypted_file
        << " - Decrypted To: " << decrypted_file << std::endl;

    return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu