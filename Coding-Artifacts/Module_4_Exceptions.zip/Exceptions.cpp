﻿// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>   // std::runtime_error, std::domain_error
#include <exception>   // std::exception
#include <string>      // std::string

// TODO: Create a custom exception derived from std::exception
class BankingAppException : public std::exception
{
public:
    explicit BankingAppException(std::string message) noexcept
        : message_(std::move(message))
    {
    }

    // Return the exception message text
    const char* what() const noexcept override
    {
        return message_.c_str();
    }

private:
    std::string message_;
};

static bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Intentionally throw a standard exception to simulate a failure
    throw std::runtime_error("Standard exception: simulated failure in do_even_more_custom_application_logic().");

    // Unreachable, but kept for clarity of the original intent
    // return true;
}

static void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    bool succeeded = false;

    try
    {
        succeeded = do_even_more_custom_application_logic();
    }
    catch (const std::exception& ex)
    {
        // Comment: Catch standard exceptions so the app does not crash.
        std::cout << "[Handled in do_custom_application_logic] Caught std::exception: " << ex.what() << std::endl;

        // Continue processing (do not rethrow here)
        succeeded = false;
    }

    if (succeeded)
    {
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
    else
    {
        // Comment: Continue running even though the inner logic failed.
        std::cout << "Even More Custom Application Logic did not succeed, continuing..." << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw BankingAppException("Custom exception: simulated business-rule failure in do_custom_application_logic().");

    // Unreachable, but matches the original structure
    // std::cout << "Leaving Custom Application Logic." << std::endl;
}

static float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f)
    {
        throw std::domain_error("Divide by zero error: denominator was 0.");
    }

    return (num / den);
}

static void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    float numerator = 10.0f;
    float denominator = 0.0f;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& ex)
    {
        // Comment: Catch only the specific exception type we throw in divide().
        // This prevents noexcept termination and still reports a useful message.
        std::cout << "[Handled in do_division] Caught std::domain_error: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();

        // If execution reaches here, no exception escaped do_custom_application_logic().
        std::cout << "Main completed without unhandled exceptions." << std::endl;
    }
    catch (const BankingAppException& ex)
    {
        std::cout << "[Handled in main] Caught BankingAppException: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "[Handled in main] Caught std::exception: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "[Handled in main] Caught an unknown/unhandled exception." << std::endl;
    }

    std::cout << "Program exiting normally (no crash)." << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu